### Hexlet tests and linter status:
[![Actions Status](https://github.com/Allanium/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Allanium/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/c951f3e347a2fb374872/maintainability)](https://codeclimate.com/github/Allanium/python-project-49/maintainability)

### brain-even
[![asciicast](https://asciinema.org/a/L14KGKic9KXuxSClX8f4gB4zm.svg)](https://asciinema.org/a/L14KGKic9KXuxSClX8f4gB4zm)

### brain-calc
[![asciicast](https://asciinema.org/a/13KwInbIoi14VEUwiUt1NKhAF.svg)](https://asciinema.org/a/13KwInbIoi14VEUwiUt1NKhAF)

### brain-gcd
[![asciicast](https://asciinema.org/a/yX1NPzsffxbg6Lx9SEQw7NnHS.svg)](https://asciinema.org/a/yX1NPzsffxbg6Lx9SEQw7NnHS)
