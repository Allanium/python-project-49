### Hexlet tests and linter status:
[![Actions Status](https://github.com/Allanium/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Allanium/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/c951f3e347a2fb374872/maintainability)](https://codeclimate.com/github/Allanium/python-project-49/maintainability)
