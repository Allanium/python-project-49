import prompt

def start_game():
    print('Welcome to the Brain Games!')
    return prompt.string('May I have your name? ')


def hello_user(name):
    print(f'Hello, {name}!'    
