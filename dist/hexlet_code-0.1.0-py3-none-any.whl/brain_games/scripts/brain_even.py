# !/usr/bin/env python

from brain_games.game import game
from brain_games.game_logic import even


def main():
    game(even)


if __name__ == '__main__':
    main()
    
        
