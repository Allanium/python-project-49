from brain_games import main
from random import randint


name = main()
print('Answer "yes" if the number is even, otherwise answer "no".'


def is_even(number):
    
        
